# <Repo> Risk Register (Phase A output, evolves)

Layer 1 — learned per repo. Ordering: `(Determinism desc, Severity desc, BlastRadius desc)`. Severity: S05>X>S04>S01>S03>S02>…

<!--
Entry schema:
## RR-NNN — <title>
- Source: BASE(Sxx) | INDUCED
- Design: <doc>:<line> — "<design quote>"
- CandidateCode: <file>:<line>
- WhyRisky: <one line>
- Determinism: H | M | L
- Severity: H | M | L
- BlastRadius: H | M | L
- Status: OPEN | CHECKING | CONFIRMED | FIXED | WONTFIX
- Findings: FL-NNN...
-->

## RR-001 — <title>
- Source:
- Design:
- CandidateCode:
- WhyRisky:
- Determinism:
- Severity:
- BlastRadius:
- Status: OPEN
- Findings:
