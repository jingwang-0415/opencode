# Findings Ledger (append-only, never delete history)

| FL | RR | Dimension | Design(doc:line) | Code(file:line) | Diff(设计说X/代码做Y) | Sev | Status | Fix |
|----|----|-----------|------------------|-----------------|----------------------|-----|--------|-----|

<!-- Status: OPEN | FIXED | WONTFIX. RR = RR-NNN or NEW (→ self-extension adds RR entry). -->
