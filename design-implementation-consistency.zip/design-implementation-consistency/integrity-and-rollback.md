# Integrity Gate & Commit-Level Rollback

Design docs (`design-docs/`) are immutable. Two layers enforce it. All commands run from the repo root unless noted.

> Artifacts live in `<repo>/.consistency/`. `BASELINE_COMMIT` = the SHA stored in `.consistency/baseline-commit.txt`.

## Phase 0 — Establish baseline (one-time)

```bash
cd <repo>
# 1. file baseline
rm -rf .consistency/baseline && mkdir -p .consistency/baseline
cp -r design-docs .consistency/baseline/design-docs
# 2. sha256 manifest (robust to spaces/CJK)
( cd design-docs && find . -type f -print0 | sort -z | xargs -0 sha256sum > ../.consistency/design-docs.manifest.sha256 )
# 3. commit baseline marker
git rev-parse HEAD > .consistency/baseline-commit.txt
# 4. self-check
( cd design-docs && sha256sum -c ../.consistency/design-docs.manifest.sha256 --quiet ) && echo "MANIFEST_OK"
```

## Layer 1 — File-level gate (every fix-unit, BEFORE compile & black-box)

```bash
cd <repo>/design-docs
if sha256sum -c ../.consistency/design-docs.manifest.sha256 --quiet; then
  echo "INTEGRITY_OK"
else
  echo "INTEGRITY_VIOLATION"
  TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  echo "$TS iteration=NN file-level violation:" >> ../.consistency/integrity-violations.log
  sha256sum -c ../.consistency/design-docs.manifest.sha256 2>/dev/null | grep -v ': OK' >> ../.consistency/integrity-violations.log
  cd <repo>
  cp -r .consistency/baseline/design-docs/* design-docs/   # restore docs
  # → RERUN this iteration's detect with original docs; adjust fixes; re-gate until INTEGRITY_OK
fi
cd <repo>
```

## Layer 2 — Commit-level rollback (git revert, full)

### 2a. Pre-commit guard (run BEFORE every `git commit` in this workflow)

```bash
cd <repo>
if git diff --cached --name-only --diff-filter=ACM | grep -q '^design-docs/'; then
  echo "PRECOMMIT_GUARD_VIOLATION: design-docs/ staged — unstaging & aborting"
  git restore --staged design-docs/
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) precommit-guard blocked design-docs/ staging" >> .consistency/integrity-violations.log
  # abort the commit; re-run commit WITHOUT design-docs/ (code only)
  exit 1
fi
```

### 2b. Post-commit audit (every iteration end & Phase D)

```bash
cd <repo>
BASE=$(cat .consistency/baseline-commit.txt)
# commits since baseline that touched design-docs/
POLLUTING=$(git log --name-only --pretty=format:'%H' "$BASE"..HEAD -- design-docs/)
if [ -n "$POLLUTING" ]; then
  echo "COMMIT_POLLUTION_DETECTED"
  # revert newest→oldest (git rev-list is newest-first); full revert (code fixes included)
  for sha in $(git rev-list "$BASE"..HEAD -- design-docs/); do
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) reverting polluting commit $sha" >> .consistency/integrity-violations.log
    if git revert --no-edit "$sha"; then
      echo "REVERTED $sha"
    else
      # conflict: resolve by taking the revert side for design-docs/ (restore pristine)
      git checkout HEAD -- design-docs/ 2>/dev/null || cp -r .consistency/baseline/design-docs/* design-docs/
      git add design-docs/
      git revert --continue --no-edit
    fi
  done
  # → REDO the affected iteration(s) with the pre-commit guard present
fi
```

### 2c. Redo after rollback

After `git revert`, the code fixes from the polluting commit are gone. Re-run that iteration's full loop (read → detect → fix → integrity gate → compile → black-box) with the **pre-commit guard (2a) active** on every commit, so the pollution cannot recur.

## Notes

- `git revert` is **full revert** by design (user choice): it undoes the entire polluting commit including any code fixes, guaranteeing a clean state; the iteration is then redone.
- Rollback targets ONLY commits that touched `design-docs/`. Code commits are never reverted by this mechanism.
- All pollution events (blocked, reverted) append to `.consistency/integrity-violations.log` and are reported in the iteration report (`IntegrityViolations:` field). Pollution is a process error, never a "finding".
- If the repo is not git or commits are not used, rely on Layer 1 (file-level) only and skip Layer 2.
