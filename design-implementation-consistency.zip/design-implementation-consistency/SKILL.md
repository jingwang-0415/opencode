---
name: design-implementation-consistency
description: Use when a project's design docs or specs are the acceptance baseline and code must be fixed to match them — e.g., checking design-implementation consistency, fixing code to match a frozen design/spec, design-code drift, 不一致检查/一致性校验. Use before modifying code to conform to a design baseline or frozen API contract.
---

# Design-Implementation Consistency

## Overview

Check a codebase against its design docs (the immutable baseline), find every inconsistency, fix the **code** to match the design, and iterate until complete coverage with zero new findings — without ever modifying the design docs.

Core principle: **design docs are the only truth; tests passing ≠ conforming.** A general risk-taxonomy learns each repo's high-risk points; a dimension-batch loop fixes them under a strict verify gate; a file-level + commit-level integrity guard guarantees the design docs stay pristine (auto-rollback on any pollution).

## When to Use

- A project ships design docs/specs marked as the acceptance baseline ("以设计为准", "frozen contract", "不可修改 design-docs").
- You must find where code drifts from design and fix the code (not the docs).
- Black-box tests exist but the README/spec explicitly says "passing tests ≠ conforming".
- You need a repeatable, resumable, cross-project method (not ad-hoc diffing).

Do NOT use for: greenfield feature building (use brainstorming → writing-plans); debugging a specific failure (use systematic-debugging); when code is the baseline and docs should be regenerated.

## The Three-Layer Risk Model

```
Layer 0  Base Taxonomy (ships with skill, ~15 domain-free signals)
         │  ① top-down: scan THIS repo's design docs with the signals
         │  ② bottom-up: induce repo-specific risk patterns from docs+code
         ▼
Layer 1  Repo Risk Register  → <repo>/.consistency/risk-register.md  (per-repo, persisted, evolves)
         │  drives the check-fix loop
         ▼
Layer 2  Self-extension: a finding no register entry would catch → add entry;
         if domain-free → promote to Layer 0
```

Layer 0 is the generalization base; Layer 1 is learned per repo (the skill's output, not hardcoded); Layer 2 lets both grow. See `base-taxonomy.md` for the 15 signals.

## Workflow (Phases)

- **Phase 0 — Baseline**: snapshot `design-docs/` → `.consistency/baseline/design-docs/` + sha256 manifest + record baseline commit SHA. (One-time, read-only after.)
- **Phase A — Learn register**: top-down (signal scan) + bottom-up (repo induction) → score by (Determinism, Severity, BlastRadius) → persist `risk-register.md`.
- **Phase B — Risk-driven loop**: per register entry (dimension-batch): read → detect findings → fix code → **integrity gate → compile → black-box green** → record → **update `/result/output.md`**. Repeat until all entries FIXED/WONTFIX.
- **Phase C — Full doc scan**: doc-by-doc (01→end + appendices) vs code; new findings map to entries or trigger self-extension; update coverage-matrix; **update `/result/output.md`**.
- **Phase D — Completion gate**: full rescan zero new findings + black-box green + coverage 100%; **finalize `/result/output.md`**.

**Done** = Phase B+C complete + Phase D zero new + black-box green + coverage 100%. Not "tests pass".

## Integrity & Rollback (hard constraint)

Design docs are immutable. Two layers enforce it (full commands in `integrity-and-rollback.md`):

1. **File-level gate** (per fix-unit, before compile/black-box): rehash `design-docs/`, compare to manifest. Any change → restore from baseline → rerun this iteration's detect → re-gate.
2. **Commit-level rollback** (git revert, full):
   - **Pre-commit guard**: if any `design-docs/` file is staged, unstage + abort commit.
   - **Post-commit audit** (per iteration & Phase D): `git log <baseline>..HEAD -- design-docs/` finds polluting commits → `git revert --no-edit <sha>` (full revert, code fixes included) → redo that iteration with the guard present.

Any doc pollution = process error; logged to `integrity-violations.log`; never counted as a "finding".

## Per-Fix Verification Bar (strictest)

- After each edit: fast compile gate.
- After each fix-unit (dimension-batch): ① integrity gate ② compile ③ black-box all green. Failure → bisect within the batch; never advance with a failure.
- Unit tests in `code/` are **suspects, not truth**: if a unit test asserts behavior contradicting design, the prod code likely has the same bug — fix prod code to match design, fix/delete the contradicting test. Never cite a unit test as proof of correctness.

## Output

Every confirmed inconsistency + its full evidence chain is consolidated into **`/result/output.md`** (human-readable, outside the repo, for easy review). Updated after each Phase B/C iteration; finalized at Phase D.

Each entry carries the evidence chain:
- **设计依据**: `<doc>:<line>` + design quote
- **代码证据**: `<file>:<line>` + actual implementation
- **差异**: design says X / code does Y

Format: see `templates/output.md`. The in-repo `.consistency/findings-ledger.md` remains the append-only audit trail; `/result/output.md` is the consolidated review view. If `/result/` is not writable, create it (or fall back to `<repo>/.consistency/output.md`) and note the chosen path at the top of the file.

## Quick Reference

| Artifact (in `<repo>/.consistency/`) | Purpose |
|------|------|
| `base-taxonomy.md` | Layer 0 (skill copy) |
| `risk-register.md` | Layer 1 (learned) |
| `findings-ledger.md` / `fixes-ledger.md` | append-only logs |
| `coverage-matrix.md` | doc-section × status |
| `reports/iteration-NN.md` | per-iteration report |
| `baseline/design-docs/` + `design-docs.manifest.sha256` + `baseline-commit.txt` | immutability baseline |
| `integrity-violations.log` | pollution log |
| **`/result/output.md`** | **consolidated findings + evidence chain (human-readable, outside repo)** |

Register entry ordering: `(Determinism desc, Severity desc, BlastRadius desc)`. Severity: S05>X>S04>S01>S03>S02>…

## Common Mistakes

- **Trusting tests as truth** — tests are suspects; design docs are the only baseline.
- **Hardcoding repo-specific risks into the skill** — risks are learned per repo into Layer 1; only domain-free signals live in Layer 0.
- **Skipping the integrity gate** to save a test run — one polluted commit corrupts the baseline.
- **Fixing code by hardcoding for a specific test case** — forbidden; fix the general rule.
- **Stopping when tests pass** — stop only at complete coverage + zero new findings.
- **Modifying design docs "to match code"** — never; the direction is always code → design.

## References

- Full framework spec: `docs/superpowers/specs/2026-06-29-design-implementation-consistency-framework-design.md`
- `base-taxonomy.md` — the 15 Layer-0 signals (heavy reference)
- `integrity-and-rollback.md` — file-level gate + commit-level rollback command sequences
- `templates/` — risk-register, findings-ledger, fixes-ledger, coverage-matrix, iteration-report

**REQUIRED SUB-SKILL:** Use superpowers:subagent-driven-development to execute the per-dimension loop (fresh subagent per iteration, review between).
