# Layer 0 Base Taxonomy (15 domain-free signals)

Domain-independent; ships with the skill. Each signal: **特征** (how to spot in design docs) / **为何高风险** / **代码侧典型漂移**. The set is not assumed complete — Layer 2 self-extension discovers and adds new signals; domain-free ones promote here.

| ID | 信号 | 设计文档特征 | 为何高风险 | 代码侧典型漂移 |
|----|------|-------------|-----------|----------------|
| S01 | 多项式公式+运算顺序 | 显式公式 ≥3 项或指定运算顺序/叠加顺序 | 易漏项/乱序/舍入方向错 | 漏项、顺序错、舍入模式错 |
| S02 | 显式阈值/魔数 | 具体数值或"默认 X" | 硬编码错/读错配置键 | 魔数不符、配置键名不符 |
| S03 | 多态状态机+迁移守卫 | 枚举状态 + 迁移规则/"不可跳步" | 缺守卫/允许非法跳转 | 缺迁移校验、允许跳步 |
| S04 | 禁止/义务语 | "不得/必须/禁止/不允许" | "不许做的"最易被违反 | 缺校验、违反约束 |
| S05 | "X 而非 Y"显式纠错 | 显式对比正/误 | 已知常见错误标记,最高风险 | 实现了"Y"错误版本 |
| S06 | 冻结契约 | 标注"不可变/契约/禁止修改" | 改名/改类型/改状态码 | URL/字段/类型/状态码偏差 |
| S07 | 幂等键 | "幂等/重复/不得重复扣" | 缺幂等→重复扣款/扣库存 | 缺幂等检查、键错 |
| S08 | 跨模块契约 | 定义模块间接口/事件契约 | 实现走捷径直访对方表 | 直访对方 Repo/表、缺事件 |
| S09 | 精度/舍入/格式 | 指定精度/舍入模式/格式 | 用 double/舍入模式错 | double 代替 BigDecimal、舍入错 |
| S10 | 配置驱动+默认值 | "配置 X 默认 Y/运行期可覆盖" | 默认不符/非运行期读 | 默认值错、编译期硬编码 |
| S11 | 时间触发/过期 | 基于时间的触发/过期/TTL | 调度未实现/TTL 错 | 无调度、TTL/超时值错 |
| S12 | 错误码→HTTP 映射 | 错误码表带 HTTP 状态 | 状态码错/错误码串错 | 状态码或错误码串偏差 |
| S13 | 快照/版本化 | "快照/历史/不得受后续改动影响" | 读实时数据而非快照 | 未存快照、读 live 数据 |
| S14 | 边角分支枚举 | "若…则…"分 N 类/按状态分情况 | 只实现 happy path | 缺边角分支 |
| S15 | 并发/事务边界 | "事务/原子/回滚/并发" | 事务范围错/回滚含非关键监听 | 事务范围错、强一致监听器失败回滚主事务 |

## How to use

- **Phase A top-down**: for each signal, scan the repo's design docs for occurrences matching the 特征; each hit → candidate register entry `{Source: BASE(Sxx), Design: doc:line, CandidateCode, WhyRisky}`.
- **Phase A bottom-up**: induce repo-specific patterns not directly covered above → `Source: INDUCED`.
- **Layer 2 promotion**: when self-extension finds a new domain-free signal, append a row here (new Sxx) with a note of the source repo/context.
